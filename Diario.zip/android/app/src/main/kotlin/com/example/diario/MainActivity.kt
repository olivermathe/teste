package com.example.diario

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
